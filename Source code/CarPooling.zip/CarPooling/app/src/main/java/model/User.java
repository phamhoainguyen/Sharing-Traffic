package model;

/**
 * Created by Admin on 4/12/2017.
 */

public class User {
    private String name;
}
