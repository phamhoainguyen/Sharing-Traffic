package com.example.admin.carpooling;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import model.User;
import utils.Utils;

public class Login extends AppCompatActivity {

    private TextView txtAccount;
    private Button btnLogin;
    private EditText edtEmail;
    private EditText edtPass;
    private ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        txtAccount = (TextView) findViewById(R.id.txtAccount);
        edtEmail =(EditText) findViewById(R.id.edtEmail);
        edtPass =(EditText) findViewById(R.id.edtPass);
        txtAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Login.this,Register.class);
                startActivity(intent);
            }
        });
        btnLogin =(Button) findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = edtEmail.getText().toString();
                String pass = edtPass.getText().toString();
                if(email.length() == 0 || pass.length() == 0)
                {
                    Toast.makeText(Login.this,"Please fill all the fields",Toast.LENGTH_LONG).show();
                    return;
                }
                if(!Utils.isValidEmail(email))
                {
                    Toast.makeText(Login.this,"Email is not valid",Toast.LENGTH_LONG).show();
                    return;
                }
                FirebaseAuth.getInstance().signInWithEmailAndPassword(email,pass).addOnCompleteListener(Login.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        progressDialog.dismiss();
                        if(!task.isSuccessful())
                        {
                            Toast.makeText(Login.this,"Authenticate unsuccessfully",Toast.LENGTH_LONG).show();

                        }
                        else
                        {
                            FirebaseUser user = task.getResult().getUser();
                            Toast.makeText(Login.this,"Login successfully \nName: " + user.getDisplayName()+"\nUID: " +user.getUid()  ,Toast.LENGTH_LONG).show();



                        }

                    }
                });
                progressDialog = ProgressDialog.show(Login.this,null,"Please wait...");

            }
        });






    }

}
