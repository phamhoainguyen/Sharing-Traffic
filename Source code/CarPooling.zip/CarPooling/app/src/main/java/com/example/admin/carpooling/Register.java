package com.example.admin.carpooling;

import android.app.ProgressDialog;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;

import utils.Utils;

public class Register extends AppCompatActivity {
    final private String TAG="Register";
    private EditText edtName;
    private EditText edtEmail;
    private EditText edtPass;
    private EditText edtConfirmPass;
    private Button btnRegister;
    private ProgressDialog progressDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        edtName = (EditText) findViewById(R.id.edtName);
        edtEmail = (EditText) findViewById(R.id.edtEmail);
        edtPass = (EditText) findViewById(R.id.edtPass);
        edtConfirmPass = (EditText) findViewById(R.id.edtConfirmPass);
        btnRegister = (Button) findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               final String name = edtName.getText().toString();
                String pass = edtPass.getText().toString();
                String email = edtEmail.getText().toString();
                String confirmPass = edtConfirmPass.getText().toString();

                if(name.length() == 0 || pass.length() == 0 || email.length() == 0 || confirmPass.length() ==0 )
                {
                    Toast.makeText(Register.this,"Please fill all the fields",Toast.LENGTH_LONG).show();
                    return;
                }
                if(!Utils.isValidEmail(email))
                {
                    Toast.makeText(Register.this,"Email is not valid",Toast.LENGTH_LONG).show();
                    return;
                }

                if(pass.length() < 6)
                {
                    Toast.makeText(Register.this,"Password need at least 6 character",Toast.LENGTH_LONG).show();
                    return;
                }
                if(!confirmPass.equals(pass))
                {
                    Toast.makeText(Register.this,"Password and confirm password don't match",Toast.LENGTH_LONG).show();
                    return;
                }



                FirebaseAuth.getInstance().createUserWithEmailAndPassword(email,pass).addOnCompleteListener(Register.this,new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        progressDialog.dismiss();
                        Log.e(TAG,"create User onComplete");
                        if(!task.isSuccessful())
                        {

                            Toast.makeText(Register.this,"An account with this email already exists",Toast.LENGTH_LONG).show();
                            return;
                        }
                        else
                        {
                            FirebaseUser user = task.getResult().getUser();
                            UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                                    .setDisplayName(name)
                                    .build();
                            user.updateProfile(profileUpdates).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    Log.e(TAG,"update profile onComplete");
                                    if(task.isSuccessful())
                                    {
                                        Toast.makeText(Register.this,"Register successfully",Toast.LENGTH_LONG).show();
                                    }

                                }
                            });


                        }

                    }
                });



                progressDialog = ProgressDialog.show(Register.this,null,"Please wait...");

            }
        });


    }
}
