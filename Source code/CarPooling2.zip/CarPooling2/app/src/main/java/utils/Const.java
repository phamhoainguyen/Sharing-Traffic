package utils;

/**
 * Created by Admin on 4/21/2017.
 */

public class Const {
    public static final String DIRECTION_URL_API = "https://maps.googleapis.com/maps/api/directions/json?";
    public static final String GOOGLE_API_KEY = "AIzaSyDl-pKM4eqYmQEh0-Za4y48CnI0qgjSc-w";

    public static final String PLACES_API_BASE = "https://maps.googleapis.com/maps/api/place";
    public static final String TYPE_AUTOCOMPLETE = "/autocomplete";
    public static final String OUT_JSON = "/json";


}
