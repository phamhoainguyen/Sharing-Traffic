package com.example.admin.carpooling2;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import model.Record;

/**
 * Created by Admin on 4/22/2017.
 */

public class Result extends Fragment {
    final private String TAG = "Result";
    private RecyclerView rvRecord;
    private RecordAdapter adapter;
    private ArrayList<Record> list = new ArrayList<Record>();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.result,container,false);

        rvRecord =(RecyclerView) view.findViewById(R.id.rvRecord);
        FirebaseDatabase.getInstance().getReference().child("record").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Log.e(TAG,"onCreteView onDataChange");
                long size = dataSnapshot.getChildrenCount();
                if(size == 0)
                {
                    return;
                }
                else
                {
                    Record temp = new Record();
                    for(DataSnapshot data : dataSnapshot.getChildren())
                    {
                        temp = data.getValue(Record.class);
                        list.add(temp);
                    }
                    adapter = new RecordAdapter(list,getActivity());
                    rvRecord.setAdapter(adapter);

                    LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
                    rvRecord.setLayoutManager(linearLayoutManager);
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });




        return  view;
    }
    class RecordAdapter extends RecyclerView.Adapter<RecordAdapter.RecordViewHolder>
    {
        private ArrayList<Record> list;
        private LayoutInflater layoutInflater;
        private Context context;
        public RecordAdapter(ArrayList<Record> list, Context context)
        {
            this.list = list;
            this.context = context;
            layoutInflater = LayoutInflater.from(context);
        }

        @Override
        public RecordViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = layoutInflater.inflate(R.layout.record_item,parent,false);
            return  new RecordViewHolder(view);
        }

        @Override
        public void onBindViewHolder(RecordViewHolder holder, int position) {
            Record record = list.get(position);
            holder.txtDestination.setText(record.origin);
            holder.txtOrigin.setText(record.destination);
            holder.txtName.setText(record.name);


        }
        @Override
        public int getItemCount() {
            return list.size();
        }

        class RecordViewHolder extends RecyclerView.ViewHolder
        {
            private TextView txtName;
            private TextView txtOrigin;
            private  TextView txtDestination;

         public RecordViewHolder(View v)
         {
             super(v);
             txtName =(TextView) v.findViewById(R.id.txtName);
             txtOrigin =(TextView) v.findViewById(R.id.txtOrigin);
             txtDestination =(TextView) v.findViewById(R.id.txtDestination);

         }
        }

    }
}
