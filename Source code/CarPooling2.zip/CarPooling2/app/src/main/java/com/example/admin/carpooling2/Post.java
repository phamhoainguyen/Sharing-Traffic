package com.example.admin.carpooling2;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Fragment;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.NumberPicker;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Calendar;

import model.DirectionFinder;
import model.DirectionFinderListener;
import model.Latlng;
import model.Record;
import model.Route;
import utils.Const;

/**
 * Created by Admin on 4/16/2017.
 */

public class Post extends Fragment implements DirectionFinderListener,View.OnClickListener{
    //Tag
    private static final String TAG ="Post";


    //control


    private EditText editStartDate;
    private EditText editStartTime;
    private AutoCompleteTextView autoCompOrigin;
    private AutoCompleteTextView autoCompDes;
    private AutoCompleteTextView autoCompWayPoint;
    private NumberPicker numberPicker;
    private  EditText editPrice;


    //variable
    private Record record ;
    boolean isOriginSuggestion = false;
    boolean isDesSuggestion = false;
    boolean isWayPointSuggestion = false;


        @Nullable
        @Override

        public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
            View view = inflater.inflate(R.layout.post, container, false);


            setClick(R.id.btnPost,view);
            editPrice = (EditText) view.findViewById(R.id.editPrice);
            editStartDate = (EditText) view.findViewById(R.id.editStartDate);
            editStartDate.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if(hasFocus)
                    {
                        final Calendar c = Calendar.getInstance();
                        int mYear = c.get(Calendar.YEAR);
                        int mMonth = c.get(Calendar.MONTH);
                        int mDay = c.get(Calendar.DAY_OF_MONTH);


                        DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(),
                                new DatePickerDialog.OnDateSetListener() {

                                    @Override
                                    public void onDateSet(DatePicker view, int year,
                                                          int monthOfYear, int dayOfMonth) {

                                        editStartDate.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);
                                        editStartDate.clearFocus();

                                    }
                                }, mYear, mMonth, mDay);
                        datePickerDialog.setButton(DialogInterface.BUTTON_NEGATIVE,getString(android.R.string.cancel),new DialogInterface.OnClickListener(){
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                editStartDate.clearFocus();
                            }
                        });
                        datePickerDialog.show();
                    }
                }
            });

            editStartTime = (EditText) view.findViewById(R.id.editStartTime);
            editStartTime.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if(hasFocus)
                    {
                        final Calendar c = Calendar.getInstance();
                        int mHour = c.get(Calendar.HOUR_OF_DAY);
                        int mMinute = c.get(Calendar.MINUTE);

                        // Launch Time Picker Dialog
                        TimePickerDialog timePickerDialog = new TimePickerDialog(getActivity(),
                                new TimePickerDialog.OnTimeSetListener() {

                                    @Override
                                    public void onTimeSet(TimePicker view, int hourOfDay,
                                                          int minute) {

                                        editStartTime.setText(hourOfDay + ":" + minute);
                                        editStartTime.clearFocus();
                                    }
                                }, mHour, mMinute, false);
                        timePickerDialog.show();

                    }

                }
            });

            //AutoComplete Origin
            autoCompOrigin = (AutoCompleteTextView) view.findViewById(R.id.autoCompOrigin);

            autoCompOrigin.setAdapter(new GooglePlacesAutocompleteAdapter(getActivity(), R.layout.list_item));
            autoCompOrigin.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Log.e(TAG,"onItemClick");
                    isOriginSuggestion = true;


                }
            });
            autoCompOrigin.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {


                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {


                }

                @Override
                public void afterTextChanged(Editable s) {
                    Log.e(TAG,"afterTextChanged");
                    isOriginSuggestion = false;

                }
            });
            autoCompOrigin.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    Log.e(TAG,"onFocusChanged");
                    if(!hasFocus && !isOriginSuggestion)
                    {
                        autoCompOrigin.setText("");


                    }
                }
            });

            //AutoComplete Des
            autoCompDes = (AutoCompleteTextView) view.findViewById(R.id.autoCompDes);
            autoCompDes.setAdapter(new GooglePlacesAutocompleteAdapter(getActivity(), R.layout.list_item));
            autoCompDes.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    isDesSuggestion = true;


                }
            });
            autoCompDes.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {


                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {


                }

                @Override
                public void afterTextChanged(Editable s) {
                    Log.e(TAG,"afterTextChanged");
                    isDesSuggestion = false;

                }
            });
            autoCompDes.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    Log.e(TAG,"onFocusChanged");
                    if(!hasFocus && !isDesSuggestion)
                    {
                        autoCompDes.setText("");


                    }
                }
            });
            //AutoComplete Way Point
            autoCompWayPoint = (AutoCompleteTextView) view.findViewById(R.id.autoCompWayPoint);
            autoCompWayPoint.setAdapter(new GooglePlacesAutocompleteAdapter(getActivity(), R.layout.list_item));
            autoCompWayPoint.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    isWayPointSuggestion = true;


                }
            });
            autoCompWayPoint.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {


                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {


                }

                @Override
                public void afterTextChanged(Editable s) {
                    Log.e(TAG,"afterTextChanged");
                    isWayPointSuggestion = false;

                }
            });
            autoCompWayPoint.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    Log.e(TAG,"onFocusChanged");
                    if(!hasFocus && !isWayPointSuggestion)
                    {
                        autoCompWayPoint.setText("");


                    }
                }
            });

            //number Picker
            numberPicker = (NumberPicker) view.findViewById(R.id.numberPicker);
            numberPicker.setMinValue(1);
            numberPicker.setMaxValue(50);
            setClick(R.id.radioMotobike,view);
            setClick(R.id.radioCar,view);
            setClick(R.id.radioPassenger,view);



            return view;
        }
    public View setClick(int id,View parent)
    {

        View v = parent.findViewById(id);
        if (v != null)
            v.setOnClickListener(this);
        return v;
    }


    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.btnPost)
        {
            String origin = autoCompOrigin.getText().toString();
            String destination = autoCompDes.getText().toString();
            String wayPoint = autoCompWayPoint.getText().toString();
            int radioCheckedID = ((RadioGroup) getView().findViewById(R.id.radioVehiclegroup)).getCheckedRadioButtonId();
            String date = editStartDate.getText().toString();
            String time = editStartTime.getText().toString();
            String price = editPrice.getText().toString();
            if(origin.isEmpty() || destination.isEmpty() || radioCheckedID == -1 || date.isEmpty() || time.isEmpty() || price.isEmpty())
            {
                Toast.makeText(getActivity(),"Please fill all the fields",Toast.LENGTH_LONG).show();
                return;
            }

            record = new Record();
            record.origin = origin;
            record.destination = destination;


            record.uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
            record.name = FirebaseAuth.getInstance().getCurrentUser().getDisplayName();
            record.wayPoint = wayPoint;
            record.vehicle = ((RadioButton) getView().findViewById(radioCheckedID)).getText().toString();
            record.date = date;
            record.time = time;
            record.sit = numberPicker.getValue();
            record.luggage = ((CheckBox) getView().findViewById(R.id.ckLuggage)).isChecked();
            record.price = price;

            try {
                new DirectionFinder(this,origin,destination, record.wayPoint).execute();
            }
            catch (UnsupportedEncodingException e)
            {

            }



        }
        else if(v.getId() == R.id.radioMotobike)
        {
            numberPicker.setMinValue(1);
            numberPicker.setMaxValue(1);
        }
        else if(v.getId() == R.id.radioCar)
        {
            numberPicker.setMinValue(1);

            numberPicker.setMaxValue(7);
        }
        else if(v.getId() == R.id.radioPassenger)
        {
            numberPicker.setMinValue(1);

            numberPicker.setMaxValue(50);
        }

    }

    public static ArrayList autocomplete(String input) {
        ArrayList resultList = null;

        HttpURLConnection conn = null;
        StringBuilder jsonResults = new StringBuilder();
        try {
            StringBuilder sb = new StringBuilder(Const.PLACES_API_BASE + Const.TYPE_AUTOCOMPLETE + Const.OUT_JSON);
            sb.append("?key=" + Const.GOOGLE_API_KEY);
            sb.append("&components=country:vn");
            sb.append("&input=" + URLEncoder.encode(input, "utf8"));

            URL url = new URL(sb.toString());
            conn = (HttpURLConnection) url.openConnection();
            InputStreamReader in = new InputStreamReader(conn.getInputStream());

            // Load the results into a StringBuilder
            int read;
            char[] buff = new char[1024];
            while ((read = in.read(buff)) != -1) {
                jsonResults.append(buff, 0, read);
            }
        } catch (MalformedURLException e) {
            Log.e(TAG, "Error processing Places API URL", e);
            return resultList;
        } catch (IOException e) {
            Log.e(TAG, "Error connecting to Places API", e);
            return resultList;
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }

        try {
            // Create a JSON object hierarchy from the results
            JSONObject jsonObj = new JSONObject(jsonResults.toString());
            JSONArray predsJsonArray = jsonObj.getJSONArray("predictions");

            // Extract the Place descriptions from the results
            resultList = new ArrayList(predsJsonArray.length());
            for (int i = 0; i < predsJsonArray.length(); i++) {
                System.out.println(predsJsonArray.getJSONObject(i).getString("description"));
                System.out.println("============================================================");
                resultList.add(predsJsonArray.getJSONObject(i).getString("description"));
            }
        } catch (JSONException e) {
            Log.e(TAG, "Cannot process JSON results", e);
        }

        return resultList;
    }

    class GooglePlacesAutocompleteAdapter extends ArrayAdapter implements Filterable {
        private ArrayList resultList;

        public GooglePlacesAutocompleteAdapter(Context context, int textViewResourceId) {
            super(context, textViewResourceId);
        }

        @Override
        public int getCount() {
            return resultList.size();
        }

        @Override
        public String getItem(int index) {
            return resultList.get(index).toString();
        }

        @Override
        public Filter getFilter() {
            Filter filter = new Filter() {
                @Override
                protected FilterResults performFiltering(CharSequence constraint) {
                    FilterResults filterResults = new FilterResults();
                    if (constraint != null) {
                        // Retrieve the autocomplete results.
                        resultList = autocomplete(constraint.toString());

                        // Assign the data to the FilterResults
                        filterResults.values = resultList;
                        filterResults.count = resultList.size();
                    }
                    return filterResults;
                }

                @Override
                protected void publishResults(CharSequence constraint, FilterResults results) {
                    if (results != null && results.count > 0) {
                        notifyDataSetChanged();
                    } else {
                        notifyDataSetInvalidated();
                    }
                }
            };
            return filter;
        }
    }

    //onDirectionsuccess

    @Override
    public void onDirectionFinderSuccess(Route route) {
        record.startLocation = new Latlng(route.startLocation.latitude,route.startLocation.longitude);
        record.endLocation = new Latlng(route.endLocation.latitude,route.endLocation.longitude);
        Intent intent = new Intent(getActivity(),Map.class);
        Map.route = route;
        startActivityForResult(intent,1);




    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        Log.e(TAG,"onActivityResult requestCode=" + requestCode + " resultCode=" + resultCode);
        if(requestCode == 1)
        {
            if(resultCode == Activity.RESULT_OK)
            {
                Log.e(TAG,"onActivityResult result_ok");

              String key = FirebaseDatabase.getInstance().getReference("record").push().getKey();
                FirebaseDatabase.getInstance().getReference("record").child(key).setValue(record).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful())
                        {
                            Toast.makeText(getActivity(),"Post Successfully",Toast.LENGTH_LONG).show();
                        }
                    }
                });

            }
            else if(requestCode == Activity.RESULT_CANCELED)
            {

            }
        }
    }
}
