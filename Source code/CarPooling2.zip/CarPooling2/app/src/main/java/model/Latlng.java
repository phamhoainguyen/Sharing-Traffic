package model;



/**
 * Created by Admin on 4/23/2017.
 */

public class Latlng {
    public double latitude;
    public double longitude;
    public Latlng(){};
    public Latlng(double latitude,double longitude)
    {
        this.latitude = latitude;
        this.longitude = longitude;
    }

}
